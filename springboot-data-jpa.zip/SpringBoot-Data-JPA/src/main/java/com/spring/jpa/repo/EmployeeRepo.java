package com.spring.jpa.repo;

import java.util.List;

import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.spring.jpa.entity.Employee;


//T =Type of an entity
//ID = Type of primary key

@Repository
public interface EmployeeRepo extends JpaRepository<Employee,Integer> {
	
	//Custom Query Methods
	List<Employee> findByDept(String dept);
	
	List<Employee> findBySalaryGreaterThan(double salary);
	
	List<Employee> findBySalaryBetween(double min,double max);
	
	List<Employee> findBySalaryLessThan(double salary);
	
	List<Employee> findBySalaryGreaterThanEqual(double salary);

	
	
	

}
