package com.spring.jpa.runner;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Order;
import org.springframework.stereotype.Component;

import com.spring.jpa.SpringBootDataJpaApplication;
import com.spring.jpa.entity.Employee;
import com.spring.jpa.repo.EmployeeRepo;

@Component
public class EmployeeRunner implements CommandLineRunner {
	

	@Autowired
	EmployeeRepo repo;
	
	
	@Override
	public void run(String... args) throws Exception {
		Employee e1=new Employee(1, "Sudha", "Development", 25000);
		Employee e2=new Employee(2, "Harshita", "Development", 45000);
		Employee e3=new Employee(3, "Nikhita", "Testing", 30000);
		Employee e4=new Employee(4, "Lavanya", "Automation Testing", 35000);
		
		repo.saveAll(List.of(e1,e2,e3,e4));
		
		repo.findAll().forEach(System.out::println);
		System.out.println("Custom Query Method");
		repo.findByDept("Testing").forEach(System.out::println);
		
		System.out.println("Salary Greater Than");
		repo.findBySalaryGreaterThan(25000).forEach(System.out::println);

		System.out.println("Salary Between");
		repo.findBySalaryBetween(10000, 40000).forEach(System.out::println);

		System.out.println("Salary Lesser Than");
		repo.findBySalaryLessThan(35000).forEach(System.out::println);
		
		System.out.println("Salary Greater Than Equal");
		repo.findBySalaryGreaterThanEqual(35000).forEach(System.out::println);
		
		
	//	Sort sortasc = Sort.by(Order.asc("Salary"));
	//	List<Employee> sortedemployees = repo.findAll(sortasc);
	//	sortedemployees.forEach(System.out::println);
		
	
	}

}
